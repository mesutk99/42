/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mkureksi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 13:21:05 by mkureksi          #+#    #+#             */
/*   Updated: 2022/11/01 14:50:13 by mkureksi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_atoi(char *str)
{
	int	s;
	int	result;
	int	i;

	s = 1;
	result = 0;
	i = 0;
	while (str[i] >= '\t' && str[i] <= '\r' || str[i] == ' ')
			i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			s *= -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		result = (str[i] - '0') + (result * 10);
		i++;
	}
	return (result * s);
}
/*
int	main(void)
{
	char *s = "--3sad1231";
	printf("%d",ft_atoi(s));
}
*/
