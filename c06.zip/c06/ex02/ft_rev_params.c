/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mkureksi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 15:57:36 by mkureksi          #+#    #+#             */
/*   Updated: 2022/11/01 16:25:39 by mkureksi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while ((str[i] != '\0'))
	{
		ft_putchar((str[i]));
		i++;
	}
	ft_putchar('\n');
}

int	main(int ac, char **av)
{
	int	i;

	i = 0;
	while (++i < ac)
		ft_putstr(av[ac - i]);
}
