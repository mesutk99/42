/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mucalisk <mucalisk@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/23 15:20:15 by mucalisk          #+#    #+#             */
/*   Updated: 2022/10/24 19:36:58 by mucalisk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	ft_putchar(char c)
{
	write (1, &c, 1);
	return (0);
}

void	ft_hexadecimal(unsigned char hex)
{
	ft_putchar("0123456789abcdef"[hex / 16]);
	ft_putchar("0123456789abcdef"[hex % 16]);
}

void	ft_putstr_non_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] < 32 || str[i] == 127))
			ft_putchar(str[i]);
		else if (str[i] < 32 || str[i] == 127)
		{
			write(1, "\\", 1);
			ft_hexadecimal(str[i]);
		}
		i++;
	}
}
